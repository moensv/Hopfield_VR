from exercise1_1 import exercise1_1
from exercise1_3 import exercise1_3
from exercise2 import exercise2
from exercise3 import exercise3
from exercise4 import exercise4

def main():
    exercise1_1()
    exercise1_3()
    exercise2()
    exercise3()
    exercise4()


if __name__=="__main__":
	main() 
